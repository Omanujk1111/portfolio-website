
import React, { useEffect, useState } from 'react';
import useMousePosition from '@/hooks/useMousePosition';

const CustomCursor = () => {
  const { x, y } = useMousePosition();
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseOver = (e) => {
      const target = e.target;
      if (
        target.tagName.toLowerCase() === 'a' ||
        target.tagName.toLowerCase() === 'button' ||
        target.closest('a') ||
        target.closest('button') ||
        target.classList.contains('cursor-pointer')
      ) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mouseover', handleMouseOver);
    return () => window.removeEventListener('mouseover', handleMouseOver);
  }, []);

  // Don't render if mouse position is at default (0,0) to avoid cursor stuck in corner on load
  if (x === 0 && y === 0) return null;

  return (
    <div
      className={`fixed top-0 left-0 rounded-full pointer-events-none z-[9999] mix-blend-difference transition-all duration-150 ease-out flex items-center justify-center`}
      style={{
        transform: `translate(${x}px, ${y}px) translate(-50%, -50%)`,
        width: isHovering ? '48px' : '16px',
        height: isHovering ? '48px' : '16px',
        backgroundColor: isHovering ? 'rgba(255, 255, 255, 1)' : 'rgba(6, 182, 212, 1)',
        willChange: 'transform, width, height, background-color'
      }}
    />
  );
};

export default CustomCursor;
